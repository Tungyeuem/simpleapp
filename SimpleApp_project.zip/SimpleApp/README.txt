BIÊN DỊCH VÀ KÝ APK

1. Mở thư mục này bằng Android Studio (tự tạo gradle wrapper và tải SDK).

2. Tạo keystore (chạy 1 lần, giữ file .jks cẩn thận):
   keytool -genkeypair -v -keystore my-release-key.jks -alias simpleapp -keyalg RSA -keysize 2048 -validity 10000

3. Copy keystore.properties.example thành keystore.properties rồi điền mật khẩu.

4. Build:
   ./gradlew assembleDebug    -> app/build/outputs/apk/debug/   (ký bằng khóa debug)
   ./gradlew assembleRelease  -> app/build/outputs/apk/release/ (ký bằng keystore của bạn)

Hoặc trong Android Studio: Build > Generate Signed Bundle / APK.
