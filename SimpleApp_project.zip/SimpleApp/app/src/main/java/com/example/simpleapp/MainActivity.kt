package com.example.simpleapp

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Free Fire thường, rồi Free Fire MAX
    private val gamePackages = listOf("com.dts.freefireth", "com.dts.freefiremax")

    private lateinit var btnLaunch: Button
    private var pulse: ObjectAnimator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        window.statusBarColor = Color.parseColor("#05070F")
        window.navigationBarColor = Color.parseColor("#1A0B3A")

        btnLaunch = findViewById(R.id.btnLaunch)
        btnLaunch.setOnClickListener { launchFreeFire() }
    }

    override fun onResume() {
        super.onResume()
        // Hiệu ứng nhịp đập cho nút
        pulse = ObjectAnimator.ofPropertyValuesHolder(
            btnLaunch,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.04f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.04f)
        ).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    override fun onPause() {
        pulse?.cancel()
        btnLaunch.scaleX = 1f
        btnLaunch.scaleY = 1f
        super.onPause()
    }

    private fun launchFreeFire() {
        val intent = gamePackages.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, R.string.not_installed, Toast.LENGTH_SHORT).show()
            openStore(gamePackages.first())
        }
    }

    private fun openStore(pkg: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$pkg")))
        } catch (e: ActivityNotFoundException) {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$pkg"))
            )
        }
    }
}
